<?php

namespace Indusa\Service\Cron;
use Indusa\Service\Logger\Logger; 

class Importproduct
{
	protected $logger;
 
	public function __construct(
		\Indusa\Service\Logger\Logger $logger
	) {
		$this->logger = $logger;
	}
 
	public function execute() {

		//test command line
        //php bin/magento cron:run --group="indusa_service_cron_group"
		$this->logger->info('test debbuging in indusa service');

	}
}