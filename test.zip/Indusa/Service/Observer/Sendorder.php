<?php
namespace Indusa\Service\Observer;

class Sendorder implements \Magento\Framework\Event\ObserverInterface
{
    public $logger;
     public function __construct(
        \Indusa\Service\Logger\Logger $logger    
    ) {
        $this->logger = $logger;
      
    }
    
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
    $order = $observer->getData('order');
     
    $orderId = $order->getIncrementId();
     $classes =  get_class($order);
	 //$order->doSomething();
    $billingAddress = $order->getBillingAddress();
    $this->logger->info('Billing Info1', $billingAddress->getData());
     
    $shippingAddress = $order->getShippingAddress(); 
    $this->logger->info('Shipping Info1', $shippingAddress->getData());
     
   /* $shippingMethod = $order->getShippingMethod();
    $classes =  get_class($shippingMethod);
    $this->logger->info('Shipping Method Info', $classes);
     */
     $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $orderObj = $objectManager->get('Magento\Sales\Model\Order');
    $order_information = $orderObj->loadByIncrementId($orderId);
    $OrderInfo = $order_information->getData();
    
    
    foreach ($order_information->getAllItems() as $item) {
        // print_r($item->getData());
  }
    
  //  $orderInfoArr = json_decode($OrderInfo,true);
  //  $this->logger->info('Order Info', $orderInfoArr);
    

  //  $shippingMethod = $orderInfoArr['shipping_amount'];
   
    //$this->logger->info('Shipping Method Info',$shippingMethod);
   
    

     return $this;
  }
}