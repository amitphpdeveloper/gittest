<?php

namespace Indusa\Service\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface{

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context){
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.1') < 0){
			
			 $table = $installer->getConnection()
            ->newTable($installer->getTable('sync'))
            ->addColumn(
                'id',
                Table::TYPE_SMALLINT,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )
            ->addColumn('method', Table::TYPE_TEXT, 100, ['nullable' => true, 'default' => null])
            ->addColumn('last_sync_date', Table::TYPE_TEXT, null, ['nullable' => false], 'API Last Date & time')
            ->setComment('ApI last sync Table');

        $installer->getConnection()->createTable($table);
			
			
		}	
		
        
	
		$installer->endSetup();			
	}

}