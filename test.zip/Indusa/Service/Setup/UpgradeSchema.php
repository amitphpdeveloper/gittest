<?php

namespace Indusa\Service\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class UpgradeSchema implements UpgradeSchemaInterface{

    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context){
        $installer = $setup;
        $installer->startSetup();
        if (version_compare($context->getVersion(), '1.0.1') < 0){
		
            
         /*    $orderTable = 'sales_order';
            
            $table = $installer->getConnection()
                    ->addColumn(
                        $setup->getTable($orderTable),
                        'sync_to_ax',
                        [
                           'type'=> \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                           'length' => 255,
                           'comment' => 'is sync with ax',
                           'default' => 'No'
                        ]   
                    );
            
            $table = $installer->getConnection()
                    ->addColumn(
                        $setup->getTable($orderTable),
                        'ax_response',
                        [
                           'type'=> \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                           'length' => 255,
                           'comment' => 'get ax response',
                           'default' => 'No'
                        ]   
                    );*/
		}	
		$installer->endSetup();			
	}

}