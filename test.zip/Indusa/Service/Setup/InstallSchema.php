<?php

namespace Indusa\Service\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\DB\Adapter\AdapterInterface;

class InstallSchema implements InstallSchemaInterface
{
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.0') < 0){

            // Changes here.
        
        $table = $installer->getConnection()
            ->newTable($installer->getTable('ax_api_request'))
            ->addColumn(
                'id',
                Table::TYPE_SMALLINT,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )
            ->addColumn('ax_request_id', Table::TYPE_INTEGER, null, ['nullable' => true, 'default' => null])
            ->addColumn('type', Table::TYPE_TEXT, 100, ['nullable' => true, 'default' => null])
            ->addColumn('request_uri', Table::TYPE_TEXT, 255, ['nullable' => false], 'API request URL')
            ->addColumn('request_params', Table::TYPE_TEXT, '1000M', [], 'API request')    
	    ->addColumn('response_params', Table::TYPE_TEXT, '100M', [], 'API response')
            ->addColumn('ack_to_ax', Table::TYPE_INTEGER, NULL, ['default' => 0], 'Acknowledgemento to ax')
            ->addColumn('process_status', Table::TYPE_INTEGER, NULL, ['default' => 0], 'status of process')
	    ->addColumn('process_list', Table::TYPE_TEXT, 4000, [], 'list of api request data')
            ->addColumn('application_id', Table::TYPE_TEXT, 255, ['nullable' => false], 'API request application id')
	    ->addColumn('token', Table::TYPE_TEXT, '1M', ['nullable' => false], 'API request Token')
            ->addColumn('creation_time', Table::TYPE_DATETIME, null, ['nullable' => false], 'API request Date & time')
            ->addColumn('update_time', Table::TYPE_DATETIME, null, ['nullable' => false], 'Update Time')
            ->setComment('ApI information Table');

        $installer->getConnection()->createTable($table);
		
		}

        $installer->endSetup();

    }
}