<?php

namespace Indusa\Service\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
 
/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * EAV setup factory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;
 
    /**
     * Init
     *
     * @param EavSetupFactory $eavSetupFactory
     */
    public function __construct(EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }
 
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        if (version_compare($context->getVersion(), '1.0.0') < 0){

            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'is_featured');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'is_featured',
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'Is featured?',
                'input' => 'select',
                'class' => '',
                'source' => 'Indusa\Service\Model\Product\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );    
                
            
            
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'is_hotseller');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'is_hotseller',
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'is Hotseller?',
                'input' => 'select',
                'class' => '',
                'source' => 'Indusa\Service\Model\Product\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );  
                
		
			
	    $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'online');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'online',
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'is Online',
                'input' => 'select',
                'class' => '',
                'source' => 'Indusa\Service\Model\Product\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );			
	
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'only_home_delivery');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'only_home_delivery',
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'is Home Delivery',
                'input' => 'select',
                'class' => '',
                'source' => 'Indusa\Service\Model\Product\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );
	
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'product_video_url');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'product_video_url',
            [
                'type' => 'varchar',
                'backend' => '',
                'frontend' => '',
                'label' => 'Product Video Url',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );

            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'ax_product_id');
	  
            $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'ax_product_id',
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => 'Ax Product id',
                'input' => 'text',
                'class' => '',
                'source' => '',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );
     }

    }
}