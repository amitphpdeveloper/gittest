<?php
namespace Indusa\Service\Model;

class Savetranscation extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Indusa\Service\Model\ResourceModel\Savetranscation');
    }
    
    public function saveResponse($jsonData,$apiUrl,$response,$apiMethod,$accessToken,$applicationID)
	{
		$productdata = json_encode($jsonData);
		$length = 16;
		$url = $apiUrl;
		$data = $response;
		$apiMethod = $apiMethod;
		$token = $accessToken;
		$apiData = array();
		$apiData['method'] = $apiMethod;
                $apiData['request_uri'] = $url;
		$apiData['response'] = $data;
		$apiData['application_id'] = $applicationID;
                $apiData['token'] = $token;	
		$apiData['creation_time'] = date('Y-m-d H:i:s');
                $apiData['update_time'] = date('Y-m-d H:i:s');
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
   
		$model = $objectManager->create('Indusa\Service\Model\Savetranscation');
                $model->setData($apiData);
		 
		try {
                   $model->save();
		}
		catch (\Exception $e) {
                        echo "message==".$e->getMessage();
            }		
	}
        
    public function saveProcessQue($QueInfo)
    {
        if(!$QueInfo) return false;
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $model = $objectManager->create('Indusa\Service\Model\Savetranscation');
                $model->setData($QueInfo);
        try {
                   $model->save();
		}
		catch (\Exception $e) {
                        echo "message==".$e->getMessage();
            }
    }
}
?>