<?php

namespace Indusa\Service\Model;


use Indusa\Service\Api\Data\DataInterface;

class Data implements \Indusa\Service\Api\Data\DataInterface
{
    
    
     /**
     * Initialize resources
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Magento\Catalog\Model\ResourceModel\Product');
    }
   /**
     * Retrieve sku through type instance
     *
     * @return string
     */
    public function getSku()
    {
        return 'test44';
    }
	
	/**
     * Set product sku
     *
     * @param string $sku
     * @return $this
     */
    public function setSku($sku)
    {
        return $sku;
    }
    
    
    /**
     * Get product name
     *
     * @return string
     * @codeCoverageIgnoreStart
     */
    public function getName()
    {
        return $this->NAME;
    }

   /**
     * Set product name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name)
    {
       
        return $this->NAME = $name;
    }
}