<?php
namespace Indusa\Service\Model\ResourceModel;

class Sync extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('sync', 'id');
    }
}
?>