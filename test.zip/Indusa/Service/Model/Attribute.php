<?php
namespace Indusa\Service\Model;

use Magento\Framework\App\ObjectManager;


class Attribute extends \Magento\Framework\Model\AbstractModel
{
    protected $_storeManager;
    protected $categoryRepository;
    
    
    public $_objectManager;
    public $_eavConfig;
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
    //  $this->_storeManager = $storeManager;
    //  $this->categoryRepository = $categoryRepository;
        
       $objectManager = ObjectManager::getInstance(); 
        
      $this->_objectManager = $objectManager;
      
      
    }
    
    public function implementAttribute($attr_code,$attr_value)
    {
        $isExistattribute = $this->loadAttribute($attr_code);
        
        if($isExistattribute)
        {
            echo "exist attribute id==".$isExistattribute->getId();
        }
        else
        {
            $this->createAttribute($attr_code);
           // echo "not exist";
        }
        
        die('stop exe');
    }
    
    
    protected function loadAttribute($attributeCode)
    {
        //  $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
       
       $eavConfig =  $this->_objectManager->get('\Magento\Eav\Model\Config'); 
        
        $attribute = $eavConfig->getAttribute('catalog_product', $attributeCode);
        if (!$attribute || !$attribute->getAttributeId()) {
           return false;
        }
        else
        {
           $productAttributeRepository = $this->_objectManager->get('Magento\Catalog\Model\Product\Attribute\Repository');

           return $productAttributeRepository->get($attributeCode);
        }
        

    }
    
    public function createAttribute($attributeCode)
    {

       $eavConfig =  $this->_objectManager->get('\Magento\Eav\Setup\EavSetup');   
       
       echo "code==".$attributeCode;
       
       
       $eavConfig->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            $attributeCode,
            [
                'type' => 'int',
                'backend' => '',
                'frontend' => '',
                'label' => $attributeCode,
                'input' => 'select',
                'class' => '',
                'source' => 'Indusa\Service\Model\Product\Attribute\Source\Boolean',
                'global' => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => false,
                'default' => 0,
                'searchable' => false,
                'filterable' => false,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false,
                'apply_to' => ''
            ]
        );
        
//EavSetup
        
    }
}
?>