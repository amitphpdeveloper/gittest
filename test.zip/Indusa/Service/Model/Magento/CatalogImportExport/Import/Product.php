<?php

namespace Indusa\Service\Model\Magento\CatalogImportExport\Import;


class Product extends \Magento\CatalogImportExport\Model\Import\Product
{
    
    
    public function validateProduct(array $rowData)
    {
        $productData = $rowData;
        $ErrorProduct = array();
        $validateTrueArr = array();
        $finalArr = array();
        foreach($productData as $productInfo)
        {
            if (!$this->validator->isValid($productInfo)) {
                foreach ($this->validator->getMessages() as $message) {
                    $ErrorProduct[$productInfo['sku']][] = $message;
                }
            }
            else
            {
                $validateTrueArr[] =  $productInfo;
                $validateSku[] = $productInfo['sku'];
            }
        }
        
        $finalArr['validateArr'] = $validateTrueArr;
        $finalArr['errorArr'] = $ErrorProduct;
        $finalArr['ValidateSku'] = $validateSku;
        return $finalArr;
    }
    
    
    
    
	
	
}
	
	