<?php
namespace Indusa\Service\Model;

use Magento\Catalog\Api\CategoryRepositoryInterface;

class Service
{
    protected $_storeManager;
    protected $categoryRepository;
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct(\Magento\Store\Model\StoreManagerInterface $storeManager, CategoryRepositoryInterface $categoryRepository)
    {
      $this->_storeManager = $storeManager;
      $this->categoryRepository = $categoryRepository;
    }
    
    public  function getCategory($categoryIds = null)
    {
        if(!$categoryIds) return;
        $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $categoryIdArr = $categoryIds;
        if(!is_array($categoryIds)) {$categoryIdArr = explode(",",$categoryIdArr);}
       
        $catTxt = 'Default Category';
        $newTxt = '';
      
        $categoryInfo = array();
        foreach($categoryIdArr as $_categoryIdArrid)
        {  
            $newTxt = $catTxt;
           $currentCat = $_objectManager->create('Magento\Catalog\Model\Category')->load($_categoryIdArrid);
           foreach ($currentCat->getParentCategories() as $parent) {
               if($parent->getId() != 2)
               {   
               $categoryInfo[$currentCat->getName()][$parent->getName()] = $parent->getId();
               $newTxt .= "/".$parent->getName();
               }
            }
            $catstingarr[$currentCat->getName()] = $newTxt;
        }
     
       $catsting = implode(",",$catstingarr);
       return $catsting;
    }
}
?>