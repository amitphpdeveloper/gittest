<?php

namespace Indusa\Service\Model\Export;


class Orderapi extends \Magento\Framework\Model\AbstractModel {

   

    public function __construct() {
      
    }

  

}
