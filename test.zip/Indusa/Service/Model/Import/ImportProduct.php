<?php

namespace Indusa\Service\Model\Import;

use Magento\Backend\App\Area\FrontNameResolver;
use Magento\Framework\App\ObjectManager\ConfigLoader;
use Magento\Framework\App\ObjectManagerFactory;
use Magento\Framework\App\State;
use Magento\ImportExport\Model\Import;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManager;

class ImportProduct extends \Magento\Framework\Model\AbstractModel {

    protected $objectManager;
    private $objectManagerFactory;

    public function __construct(ObjectManagerFactory $objectManagerFactory) {
        $this->objectManagerFactory = $objectManagerFactory;
    }

    public function importSimpleProductData($simpleProductArr) {

        $omParams = $_SERVER;
        $omParams[StoreManager::PARAM_RUN_CODE] = 'admin';
        $omParams[Store::CUSTOM_ENTRY_POINT_PARAM] = true;
        $this->objectManager = $this->objectManagerFactory->create($omParams);

        $area = FrontNameResolver::AREA_CODE;

        /**  @var \Magento\Framework\App\State $appState */
        $appState = $this->objectManager->get('Magento\Framework\App\State');
        $appState->setAreaCode($area);
        $configLoader = $this->objectManager->get('Magento\Framework\ObjectManager\ConfigLoaderInterface');
        $this->objectManager->configure($configLoader->load($area));

        $productsArray = $simpleProductArr;

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // instance of object manager

        try {

            foreach ($productsArray as $_product) {


                //  print_r($_product);	

                $description = $_product['description'];
                $Shortdescription = $_product['short_description'];
                if (isset($_product['websiteid'])) {
                    $websiteIds = explode(",", $_product['websiteid']);
                } else {
                    $websiteIds = 1;
                }
                $attributes = $_product['attributes'];

                $product = $objectManager->create('\Magento\Catalog\Model\Product');
                $product->setWebsiteIds($websiteIds);
                $product->setSku($_product['sku']); // Set your sku here
                $product->setName($_product['name']); // Name of Product
                $product->setDescription($description); // Set your sku here
                $product->setShortDescription($Shortdescription); // Set your sku here
                $product->setAttributeSetId($_product['attribute_set_id']); // Attribute set id
                $product->setStatus($_product['status']); // Status on product enabled/ disabled 1/0
                $product->setWeight($_product['weight']); // weight of product
                $product->setVisibility($_product['visibility']); // visibilty of product (catalog / search / catalog, search / Not visible individually)
                $product->setTaxClassId($_product['tax_class_id']); // Tax class id
                $product->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
                $product->setPrice($_product['price']); // price of product
                $product->setMetaTitle($_product['meta_title']);
                $product->setMetaKeyword($_product['meta_keyword']);
                $product->setMetaDescription($_product['meta_description']);
                $product->setColor($attributes['color']);
                $product->setSize($attributes['size']);
                $product->setStockData(
                        array(
                            'use_config_manage_stock' => 0,
                            'manage_stock' => 1,
                            'is_in_stock' => $_product['is_in_stock'],
                            'qty' => $_product['qty']
                        )
                );
                $product->save();
            }

            //	$importerModel->processImport($productsArray);
            //	print_r($importerModel->getLogTrace());
            //	echo '<br><br> Erro Msg:';
            //	save 
            //    print_r($importerModel->getErrorMessages());
        } catch (Exception $e) {

            echo $e->getMessage();

            die();
        }
    }

    public function importSimpleProductDataByfiregento($simpleProductArr) 
    {
        
        $omParams = $_SERVER;
        $omParams[StoreManager::PARAM_RUN_CODE] = 'admin';
        $omParams[Store::CUSTOM_ENTRY_POINT_PARAM] = true;
        $this->objectManager = $this->objectManagerFactory->create($omParams);

        $area = FrontNameResolver::AREA_CODE;

        /**  @var \Magento\Framework\App\State $appState */
        $appState = $this->objectManager->get('Magento\Framework\App\State');
        $appState->setAreaCode($area);
        $configLoader = $this->objectManager->get('Magento\Framework\ObjectManager\ConfigLoaderInterface');
        $this->objectManager->configure($configLoader->load($area));
   
        
    //  $simpleProductArr = $this->getEntities();

        $productsArray = $simpleProductArr;

      //  print_r($productsArray);
        
        $importerModel = $this->objectManager->create('FireGento\FastSimpleImport\Model\Importer');
        $productValidateMoel = $this->objectManager->create('Indusa\Service\Model\Magento\CatalogImportExport\Import\Product');
        $apiResponse = array();
        try {
            $finalArray = $productValidateMoel->validateProduct($productsArray);
            $importProdArr = $finalArray['validateArr'];
            $ErrorProdArr = $finalArray['errorArr'];
            $validateSku = $finalArray['ValidateSku'];

        /*
         * For Configurable product
         */    
         //   $adapterFactory = $this->objectManager->create('FireGento\FastSimpleImport\Model\Adapters\NestedArrayAdapterFactory');
     //      $importerModel->setImportAdapterFactory($adapterFactory); 
            $importerModel->processImport($importProdArr);
  /*print_r($importerModel->getLogTrace());
              echo '<br><br> Erro Msg:';
              print_r($importerModel->getErrorMessages());
           
            die();*/


            foreach ($productsArray as $eachProduct) {
                if (in_array($eachProduct['sku'], $validateSku)) {

                    $productResponseStatus[] = array('sku' => $eachProduct['sku'], 'status' => 'ok', 'message' => 'Import successfully');
                }

                if (array_key_exists($eachProduct['sku'], $ErrorProdArr)) {
                    $errorMessge = implode(",", $ErrorProdArr[$eachProduct['sku']]);
                    $productResponseStatus[] = array('sku' => $eachProduct['sku'], 'status' => 'Error', 'message' => $errorMessge);
                }
            }

            $apiResponse['getProduct'] = $productResponseStatus;
            $apiResponse['responseStatus'] = 'Ok';
            $apiResponse['responseMessage'] = 'Success';
        } catch (Exception $e) {
            $apiResponse['responseStatus'] = 'Error';
            $apiResponse['responseMessage'] = $e->getMessage();
        }
        
        return $apiResponse;
    }
    
    
     /**
     * @return array
     */
    public function getEntities()
    {
        $products = [];
    /**    $products [] = array(
            'sku' => "SIMPLE-BLUE-SMALL",
            'attribute_set_code' => 'Default',
            'product_type' => 'simple',
            'product_websites' => 'base',
            'name' => 'FireGento Simple Product Blue,Size Small',
            'price' => '1.0000',
            'color' => 'blue',
            'size' => 'S'
        );
        $products [] = array(
            'sku' => "SIMPLE-RED-MIDDLE",
            'attribute_set_code' => 'Default',
            'product_type' => 'simple',
            'product_websites' => 'base',
            'name' => 'FireGento Simple Product Red,Size Middle',
            'price' => '1.0000',
            'color' => 'red',
            'size' => 'M'
        );*/

        $products [] = array(
            'sku' => 'CONFIG-Product',
            'attribute_set_code' => 'Bottom',
            'product_type' => 'configurable',
            'product_websites' => 'base',
            'name' => 'FireGento Test Product Configurable',
            'price' => '10.000',
            'configurable_variation_labels' => 'Color',
            'configurable_variations' => array(
                array(
                    'sku' => 'MY_SKU223',
                    'name' => 'FireGento Simple Product Red,Size Middle',
                    'price' => '2.0000',
                    'color' => 'Red',
                    'size' => '32'),
            )

        );


        return $products;
    }

}
