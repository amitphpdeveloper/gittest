<?php

namespace Indusa\Service\Model\Import;

use Magento\Backend\App\Area\FrontNameResolver;
use Magento\Framework\App\ObjectManager\ConfigLoader;
use Magento\Framework\App\ObjectManagerFactory;
use Magento\Framework\App\State;
use Magento\ImportExport\Model\Import;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManager;


class ImportConfigurable extends \Magento\Framework\Model\AbstractModel {

    protected $objectManager;
    private $objectManagerFactory;

    public function __construct(ObjectManagerFactory $objectManagerFactory) {
        $this->objectManagerFactory = $objectManagerFactory;
    }

   

    public function importSimpleProductDataByfiregento($simpleProductArr) 
    {
        
        $omParams = $_SERVER;
        $omParams[StoreManager::PARAM_RUN_CODE] = 'admin';
        $omParams[Store::CUSTOM_ENTRY_POINT_PARAM] = true;
        $this->objectManager = $this->objectManagerFactory->create($omParams);

        $area = FrontNameResolver::AREA_CODE;

        /**  @var \Magento\Framework\App\State $appState */
        $appState = $this->objectManager->get('Magento\Framework\App\State');
        $appState->setAreaCode($area);
        $configLoader = $this->objectManager->get('Magento\Framework\ObjectManager\ConfigLoaderInterface');
        $this->objectManager->configure($configLoader->load($area));
   
        
        $simpleProductArr = $this->getMapEntities($simpleProductArr);

        $productsArray = $simpleProductArr;

     // print_r($productsArray);
        
       
        
      //  print_r($productsArray);
        
        $importerModel = $this->objectManager->create('FireGento\FastSimpleImport\Model\Importer');
        $productValidateMoel = $this->objectManager->create('Indusa\Service\Model\Magento\CatalogImportExport\Import\Product');
        $apiResponse = array();
        try {
        
            
          $importerModel->setBehavior(Import::BEHAVIOR_APPEND);
        $importerModel->setEntityCode('catalog_product');  
        /*
         * For Configurable product
         */    
        $adapterFactory = $this->objectManager->create('FireGento\FastSimpleImport\Model\Adapters\NestedArrayAdapterFactory');
        $importerModel->setImportAdapterFactory($adapterFactory);
        $importerModel->processImport($simpleProductArr);
        
        /* print_r($importerModel->getLogTrace());
              echo '<br><br> Erro Msg:';
              print_r($importerModel->getErrorMessages());
           
            die();  */


       /*      foreach ($simpleProductArr as $eachProduct) {
                if (in_array($eachProduct['sku'], $validateSku)) {

                    $productResponseStatus[] = array('sku' => $eachProduct['sku'], 'status' => 'ok', 'message' => 'Import successfully');
                }*/

               /* if (array_key_exists($eachProduct['sku'], $ErrorProdArr)) {
                    $errorMessge = implode(",", $ErrorProdArr[$eachProduct['sku']]);
                    $productResponseStatus[] = array('sku' => $eachProduct['sku'], 'status' => 'Error', 'message' => $errorMessge);
                }
            }
*/
            $apiResponse['getProduct'] = ''; $productResponseStatus;
            $apiResponse['responseStatus'] = 'Ok';
            $apiResponse['responseMessage'] = 'Success';
        } catch (Exception $e) {
            $apiResponse['responseStatus'] = 'Error';
            $apiResponse['responseMessage'] = $e->getMessage();
        }
        
        return $apiResponse;
    }
    
    
     /**
     * @return array
     */
    public function getMapEntities($simpleProductArr)
    {
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        
        
   
        $variantProduct = $simpleProductArr['variant']['products'];
        $configProduct = [];
        $varianConfigProduct = [];
        foreach($variantProduct as $varianProduct)
        {
         $_attributeArr = array();
            foreach($varianProduct['attribute'] as $_attribute)
            { 
                $_attributeArr[$_attribute['name']] =  $_attribute['value'];
            }
            
            $configProductarr = array(
                'name' => $varianProduct['variant_name'],
                'sku' => $varianProduct['variant_sku'],
                'attribute_set_code' => 'Bottom',
                'product_type' => 'simple',
                'product_websites' => 'base',
                'price' => '0.00',
            );
            
            $configProduct[] = array_merge($configProductarr,$_attributeArr);
            
            $varianConfigProductArr = array('sku' => $varianProduct['variant_sku'],);
            
            $varianConfigProduct[] = array_merge($varianConfigProductArr,$_attributeArr);
        }
         
        $model = $objectManager->create('\Indusa\Service\Model\Service');
        $catIds =  $simpleProductArr['ax_category_id'];
        $categoriesSting = $model->getCategory($catIds);
           
        $configProduct[] = array(
            'sku' => $simpleProductArr['sku'],
            'attribute_set_code' => 'Bottom',
            'product_type' => 'configurable',
            'categories' => $categoriesSting,
            'product_websites' => 'base',
            'price' => '0.00',
            'name' => $simpleProductArr['name'],
            'configurable_variation_labels' => 'Color',
            'configurable_variations' => $varianConfigProduct
        );
         
       
        
        
        
        
        die();
        return $configProduct;
        
      
    }
    
    
    public function getCategoriesMapping()
    {
        
    }

}
