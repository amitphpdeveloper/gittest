<?php

namespace Indusa\Service\Model;


use Indusa\Service\Api\Data\DataInterface;


use Magento\Backend\App\Area\FrontNameResolver;
use Magento\Framework\App\ObjectManager\ConfigLoader;
use Magento\Framework\App\ObjectManagerFactory;
use Magento\Framework\App\State;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManager;

class Hello implements \Indusa\Service\Api\HelloInterface
{
    
	public $authorization;
	
	protected $date;
	
	public function __construct(\Magento\Framework\Stdlib\DateTime\DateTime $date)
	{
		$this->authorization = 'amit123';
                $this->date = $date;
	}
	
   /**
     * Returns greeting message to user
     *
     * @api
     * @param mixed $params Users name.
     * @return string
     */
    public function postProduct() {
        
        $postdata = file_get_contents("php://input");
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        /* RND section */
     //    $catIds = '20,21,14';
      //    $model = $objectManager->create('\Indusa\Service\Model\Service');
      //    $categoriesSting = $model->getCategory($catIds);
          
        $AttributeModel = $objectManager->create('\Indusa\Service\Model\Attribute');
        
        $AttributeModel->implementAttribute('brand2','Light Blue');
         
        //  print_r($categoriesSting);
        
        
          
          //die();
       /* ================================= */
        
        
        //$xml = (array)simplexml_load_string($postdata);
       // print_r($xml); die();
       if($postdata)
       {
           	
            $requestData =  $this->convertFormatToArray($postdata,'xml');
            $response = $this->authenticate($requestData);
            $responseStatus = 'Ok';
            if($response['ResponseStatus'] == 'Error')
	    {
                $responseStatus = 'Error';
            }        
            
            $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            $baseUrl = $storeManager->getStore()->getBaseUrl();
            
            $apiUrl = $baseUrl.'rest/v1/service/params/';
           
            $apiResponseInfo['application_id'] = $requestData['applicationID'];
            $apiResponseInfo['token'] = $requestData['accessToken'];
            $apiResponseInfo['ax_request_id'] = $requestData['ax_request_id'];
            $apiResponseInfo['type'] = 'getProduct';
            $apiResponseInfo['request_uri'] =  $apiUrl;
            $apiResponseInfo['request_params'] =  $postdata;
            $apiResponseInfo['response_params'] =  $responseStatus;
            $apiResponseInfo['process_status'] =  0;

            $apiResponseInfo['creation_time'] = date('Y-m-d H:i:s');
            $apiResponseInfo['update_time'] = date('Y-m-d H:i:s');            
            
          //  print_r($apiResponseInfo);
            $model = $objectManager->create('Indusa\Service\Model\Savetranscation');
            $model->saveProcessQue($apiResponseInfo);
       }
        
        
      
       
      
     
	//print_r($requestData);
        
      //  die();
       
       
		
		if($response['ResponseStatus'] == 'Error')
		{
		   return json_encode($response);
		}
                 $objectManager = \Magento\Framework\App\ObjectManager::getInstance();	
           //     echo "date==".$apicallDatte = $this->date->date('Y-m-d H:i:s');         
                   $apiMethod = 'getProduct';
                
		$ImportproductModel = $objectManager->get('Indusa\Service\Model\Import\ImportConfigurable');
		
		$simpleProductArr = $requestData['product'];
                
                print_r($simpleProductArr);
                
               
                
                
		$apiResponseInfo = $response;
		//$callMethod = $ImportproductModel->importSimpleProductData($simpleProductArr);
		$productResponseInfo = $ImportproductModel->importSimpleProductDataByfiregento($simpleProductArr);	
		
                
                if($apiResponseInfo['ResponseStatus'] != 'Error')
                {
                    $apiResponseInfo['applicationID'] = $requestData['applicationID'];
                    $apiResponseInfo['accessToken'] = $requestData['accessToken'];
                    $apiResponseInfo['ResponseStatus'] = $productResponseInfo['responseStatus'];
                    $apiResponseInfo['ResponseMessage'] = $productResponseInfo['responseMessage'];
                    $apiResponseInfo['getProduct'] =  $productResponseInfo['getProduct'];
                }
                
             
                $accessToken = $requestData['accessToken'];
                $applicationID = $requestData['applicationID'];
          
                $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
                $baseUrl = $storeManager->getStore()->getBaseUrl();
                
                $apiUrl = $baseUrl.'rest/v1/service/params/';
                
            //   $model = $objectManager->create('Indusa\Service\Model\Savetranscation');
             //  $model->saveResponse($jsondata,$apiUrl,json_encode($apiResponseInfo),$apiMethod,$accessToken,$applicationID);
                
             
	       return  json_encode($apiResponseInfo);
      

    }
	
	public function authenticate($requestData)
	{
		$validateJsonData = true;	
		$response["ResponseStatus"] = 'success';
		
			if (!isset($requestData['accessToken'])) {
				$validateJsonData = false;
				$response["ResponseStatus"] = 'Error';
				$ResponseMessage[] = 'Access token';
					
			}
			
			if (!isset($requestData['applicationID'])) {
				$validateJsonData = false;
				$response["ResponseStatus"] = 'Error';
				$ResponseMessage[] = 'application id';
					
			}
			
			if(!$validateJsonData)
			{
				$response["ResponseMessage"] = implode(" And ",$ResponseMessage). ' is missing';
			}
			
			
			if (isset($requestData['accessToken'])) {
				 $authorization = $this->authorization;
				 $accessToken = $requestData['accessToken'];
				 if (trim($accessToken) != $authorization) {
						// api key is not present in users table
						$response["applicationID"] = $requestData['applicationID'];
						$response["authorization"] = $authorization;
						$response["accessToken"] = $accessToken;
						$response["ResponseStatus"] = 'Error';
						$response["ResponseMessage"] = 'Invalid Token';
						
				}	
			}
			
		return $response;	
	}
        
    public function convertFormatToArray($data,$formatType = 'json')
    {
        if($formatType == 'xml')
        {
            $requestData = json_decode(json_encode((array) simplexml_load_string($data)),1);
           // $requestData = (array)simplexml_load_string($data);
        }
        
        if($formatType == 'json')
        {
             $jsondata = json_decode($data,true);
            $requestData = $jsondata['params'];
        }
        
        return  $requestData ;
    }
        
}