<?php

namespace Indusa\Service\Api\Data;


interface DataInterface
{
    
    const SKU = 'Sku';

    const NAME = 'Name';
    
    
    
     /**
     * Product sku
     *
     * @return string
     */
    public function getSku();

    /**
     * Set product sku
     *
     * @param string $sku
     * @return $this
     */
    public function setSku($sku);

    /**
     * Product name
     *
     * @return string|null
     */
    public function getName();

    /**
     * Set product name
     *
     * @param string $name
     * @return $this
     */
    public function setName($name);
}