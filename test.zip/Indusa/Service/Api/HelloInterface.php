<?php

namespace Indusa\Service\Api;

interface HelloInterface
{
    
   /**
     * Returns greeting message to user
     *
     * @api
     * @param mixed  $params.
     * @return string.
     */
    public function postProduct(); 
    
   
}