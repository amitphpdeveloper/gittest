<?php


namespace Indusa\Service\Logger;

class Logger extends \Monolog\Logger
{
    
}