<?php

namespace Indusa\Service\Controller\Import;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;

/**
 * Import Category Controller
 *
 */
class CategoryImport extends \Magento\Framework\App\Action\Action 
{
	protected $_resultPageFactory;
	
	protected $categoryArray = [
		[
			'_root' => 'Default Category',
			'_category' => 'FireGento TestCategory',
			'description' => 'Test',
			'is_active' => '1',
			'include_in_menu' => '1',
			'meta_description' => 'Meta Test',
			'available_sort_by' => 'position',
			'default_sort_by' => 'position',
		],
	];
	
   public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory)
    {
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    public function execute()
    {
		/** @var \FireGento\FastSimpleImport\Model\Importer $importerModel */
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();	
		$importerModel = $objectManager->create('FireGento\FastSimpleImport\Model\Importer');
		$importerModel->setEntityCode('catalog_category');

		try {
			$importerModel->processImport($this->categoryArray);
		} catch (\Exception $e) {
			print_r($e->getMessage());
		}
		print_r($importerModel->getLogTrace());
		print_r($importerModel->getErrorMessages());
	}
}
