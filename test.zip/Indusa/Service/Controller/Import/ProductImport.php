<?php

namespace Indusa\Service\Controller\Import;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Indusa\Service\Logger\Logger;


/**
 * Import Product Controller
 *
 */
class ProductImport extends \Magento\Framework\App\Action\Action 
{
    
     public $logger;
    
	protected $_resultPageFactory;
	
	protected $myjson = '{"params":{
	  	  "applicationID": "12027773",
		  "accessToken": "amit123",
                  "product":[{
		    "websiteid" : "1,2", 
                    "sku": "MY_SKU",
		    "attribute_set_code": "Bottom",
                    "product_type" : "simple",
                    "product_websites" : "base",
                    "name": "My Product2",
                    "price" : "1000",
                    "visibility": "Catalog, Search",
                    "tax_class_name" : "Taxable Goods",
                    "product_online": "1",
                    "weight" : 10,
                    "short_description" : "This is short test subscription",
                    "description" :"This is main test subscription",
                    "qty" : "100",
                    "is_in_stock":"in_stock",
                    "color" : "Red",
                    "size": 32,
                    "status" : 1,
                    "special_price" : "0",
                    "special_from_date" : "",
                    "special_to_date"  : "",
                    "country_of_manufacture" : "United States",
                    "seller_cost" : 200,
                    "parent_sku" : "0",
                    "meta_title" : "meta title",
                    "meta_keyword" : "testkey1, testkey2, testkey3",
                    "meta_description" : "This is meta description for",
                    "categories" : "Default Category/Gear,Default Category/Gear/Bags"
		}]
	    }
	}';

   public function __construct(Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory,\Indusa\Service\Logger\Logger $logger)
    {
        $this->_resultPageFactory = $resultPageFactory;
       $this->logger =  $logger;
        parent::__construct($context);
    }

    public function execute()
    {
        
     /*   $orderId = 11;
    
      $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $orderObj = $objectManager->get('Magento\Sales\Model\OrderRepository');
    $OrderInfo = $orderObj->get($orderId);
    
    
  foreach ($OrderInfo->getAllItems() as $item) {
 print_r($item->getData());
 
}
    die();
    */
        
        $orderId = '000000055';
         $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
    $orderObj = $objectManager->get('Magento\Sales\Model\Order');
    $order_information = $orderObj->loadByIncrementId($orderId);
  //  $OrderInfo = $order_information->getData();
    
    $orderInformationData = $order_information->getData();
    
    $lineItemsByOrderId = array();
    $orderInfo['customer_id'] = $order_information->getData('customer_id');
    $orderInfo['order_increment_id'] = $orderId;
    $orderInfo['currency'] = $order_information->getData('store_currency_code');
    $orderInfo['status'] = $order_information->getData('status');
    $orderInfo['grand_total'] = $order_information->getData('grand_total');
    $orderInfo['sub_total'] = $order_information->getData('subtotal');
    
   
 
    
    foreach ($order_information->getAllItems() as $item) {
      //   print_r($item->getData());
       //  $this->logger->info('item Data', $item->getData());
         $orderData = $item->getData();
         $orderId =$orderData['item_id'];
         if(!isset($lineItemsByOrderId[$orderId]))
         {
          
            if($orderData['parent_item_id'] == NULL) // if product is configurable
            {
                  $lineItems[$orderId]['itemId'] = $orderData['product_id'];
              $productOption  = $orderData['product_options'];
              $attributeData = $productOption['attributes_info'];
             
              foreach($attributeData as $_attribureValue)
              {
                  $label = $_attribureValue['label'];
                  $lineItems[$orderId][$label] = $_attribureValue['value'];
              }
              $lineItems[$orderId]['SalesPrice'] = $orderData['price'];
              $lineItems[$orderId]['QtyOrdered'] = $orderData['qty_ordered'];
              $lineItems[$orderId]['line_amount'] = $orderData['row_total'];
              $lineItems[$orderId]['linedisc'] = $orderData['discount_amount'];
              $lineItems[$orderId]['linepercent'] = $orderData['discount_percent'];
            }
         }
         
         
  }
  
  // Add customer infor
  
  $customer['basicDetails']['payment_method'] = '';
  $customer['basicDetails']['name'] = $orderInformationData['customer_firstname'].' '.$orderInformationData['customer_lastname'];  
  $customer['basicDetails']['email'] = $orderInformationData['customer_email'];
  
  
  $shippingAddress = $order_information->getShippingAddress(); 
  $shippingAddressData = $shippingAddress->getData();
   
  $billingAddress = $order_information->getBillingAddress(); 
  $billingAddressData = $billingAddress->getData();
  
  $customer['address']['shippping_address'] = array('name'=>$shippingAddressData['firstname'].' '.$shippingAddressData['lastname'],'locationName'=>$shippingAddressData['company'],'street'=>$shippingAddressData['street'],'city'=>$shippingAddressData['city'],'country_id'=>$shippingAddressData['country_id'],'state'=>$shippingAddressData['region']);
  $customer['address']['billing_address'] = array('name'=>$billingAddressData['firstname'].' '.$billingAddressData['lastname'],'locationName'=>$billingAddressData['company'],'street'=>$billingAddressData['street'],'city'=>$billingAddressData['city'],'country_id'=>$billingAddressData['country_id'],'state'=>$billingAddressData['region']);  
  
   $paymentInfo = $order_information->getPayment(); 
   $paymentInfoData = $paymentInfo->getData();
  
   $paymentInfo = array('PaymMode'=>$paymentInfoData['method'],'CurrencyCode'=>$order_information->getData('store_currency_code'),'amount'=>$paymentInfoData['amount_ordered']); 
  
   $orderInfo['customer'] = $customer; 
   $orderInfo['itemInfo'] = $lineItems;
   $orderInfo['payment']  = $paymentInfo;
  
  
  print_r($orderInfo);
  
  die();
    
        
        
        $postdata = $this->myjson;
        
        $jsondata = json_decode($postdata,true);
       
		$requestData = $jsondata['params'];
	//	$response = $this->authenticate($requestData);
		
		/*if($response['ResponseStatus'] == 'Error')
		{
		   return json_encode($response);
		}*/

		  $objectManager = \Magento\Framework\App\ObjectManager::getInstance();	
		$ImportproductModel = $objectManager->get('Indusa\Service\Model\Import\ImportProduct');
		
		
		$simpleProductArr = $requestData['product'];
		
		//$callMethod = $ImportproductModel->importSimpleProductData($simpleProductArr);
		$callMethod = $ImportproductModel->importSimpleProductDataByfiregento($simpleProductArr);	
		die('stop execution'); 
		return ($jsondata);
      

    }    

}
